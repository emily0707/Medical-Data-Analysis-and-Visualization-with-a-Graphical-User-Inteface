/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package staxparser;

/**
 *
 * @author feiping
 */
public class Analyte {
 private int rank;
 private String name;
 
 public int getRank() {
  return rank;
 }
 public void setRank(int rank) {
  this.rank = rank;
 }
 public String getName() {
  return name;
 }
 public void setName(String name) {
  this.name = name;
 }
}